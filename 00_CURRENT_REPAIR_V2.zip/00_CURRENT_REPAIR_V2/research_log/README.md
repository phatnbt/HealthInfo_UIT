# Research Log

Nhật ký nghiên cứu hằng ngày cho dự án NHIS 2024.

## Quy ước ghi nhật ký
Mỗi ngày giữ cùng một cấu trúc:
1. Mục tiêu trong ngày
2. Công việc đã thực hiện
3. Công cụ sử dụng
4. Các bước xử lý
5. Kết quả
6. Vấn đề phát sinh / lưu ý
7. Quyết định / bước tiếp theo
8. Sản phẩm tạo ra

## Nhật ký hiện có
- [Day 1 — Source integrity](Day01_Source_Integrity.md)
- [Day 2 — Target & cohort audit](Day02_Target_Cohort.md)
- [Day 3 — Predictor/data dictionary audit](Day03_Predictor_Dictionary.md)
- [Day 4 — Missing/code audit, EDA & post-UHS feature lock](Day04_EDA_Audit.md)
- [Day 5 — Preprocessing & baseline modeling](Day05_Baseline_Modeling.md)
- [Day 6 — Literature matrix & evidence map](Day06_Literature_Matrix.md)
- [Day 7 — Background & Related Work](Day07_Background_Related_Work.md)
- [Day 8–10 — Model tuning, preliminary calibration & locked test re-evaluation](Day08_10_Tuning_Log.md)
- [Day 8–10 addendum — UHS-requested 95% CI, calibration plots & DCA](Day08_10_UHS_Metric_Extension.md)
- [Day 11–13 — Survey-aware weighted-vs-unweighted sensitivity](Day11_13_Survey_Aware_Sensitivity.md)
- [Day 14–16 — Locked-model SHAP explainability](Day14_16_SHAP_Explainability.md)
- [Day 17–19 — Locked-test subgroup fairness and error-rate audit](Day17_19_Fairness_Audit.md)
- [Day 20–22 — Error analysis, robustness and initial code freeze](Day20_22_Error_Robustness_Code_Freeze.md)
- [Day 23–24 — Full manuscript v1 assembly from frozen evidence](Day23_24_Manuscript_Assembly.md)

Google Docs được dùng như bản cộng tác sống; thư mục này lưu phiên bản đã chốt để theo dõi lịch sử thay đổi bằng Git.
