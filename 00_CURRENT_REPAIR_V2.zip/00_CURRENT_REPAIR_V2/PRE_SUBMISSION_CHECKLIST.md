# Checklist trước submission

- [x] MI có 10 imputations, 240 performance rows và 2.880 sampled global SHAP rows; 120 additivity checks.
- [x] Giữ nguyên cohort, split, hyperparameters, probability choice và thresholds.
- [x] KG có 2 overall + 74 subgroup = 76 hàng; đối chiếu Taylor và Beta/F từng hàng.
- [x] Workbook lịch sử 18 nguồn phục hồi theo CRC; CSV19 hiện hành giữ nguyên.
- [x] Sơ đồ 12 predictors có FDSCAT3_A; legend bốn SVG có mẫu đường.
- [x] Day5 CLI chạy từ đường dẫn mới và mặc định không xuất dữ liệu dự đoán từng người.
- [x] Day22 freeze 30 hash không đổi; các gate artifact PASS trên Windows và host Linux riêng.
- [x] Linux kiểm chứng độc lập tái lập cả LR/RF/XGBoost trong tolerance 1e-8; giới hạn Windows ghi riêng.
- [x] Corrected primary SHAP full-test đã PASS; manuscript v2, figure index và claim traceability đã đồng bộ.
- [ ] UHS duyệt diễn giải, use case, scope candidate branches và bản manuscript mới.
- [ ] Đối soát template/định dạng venue và xác nhận submission version cuối.
- [ ] Historical152 manifest nếu cần xác nhận gói lịch sử đó; không tạo manifest giả.

Gói để review, chưa phải approved final submission. Nhật ký repair mới không thay các execution/approval records lịch sử chưa được cung cấp.
