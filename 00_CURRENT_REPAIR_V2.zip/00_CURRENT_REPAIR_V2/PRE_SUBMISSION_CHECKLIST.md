# Checklist trước submission
- [x] Kết quả POVRATTC_A đủ 10 imputations; tách biệt primary.
- [x] Cohort/split/input integrity và 240 performance rows đã kiểm tra.
- [x] Companion Korn–Graubard hai overall outcomes và kiểm tra Beta/F.
- [x] Literature Matrix Day 6 hiện hành 19 nguồn được sao chép nguyên vẹn.
- [x] Report, nhật ký mới, rationale, code tái lập và runtime pins có trong gói.
- [x] Manifest và checksum kiểm tra trên đúng nội dung rút gọn.
- [ ] Cung cấp manifest Repair v2 lịch sử 152 tệp nếu cần xác nhận bản lịch sử.
- [x] Tái lập trên môi trường Python mới độc lập và đối chiếu hai tiến trình đầy đủ.
- [x] Kiểm tra compiler bằng 36 fits, 72 evaluation rows và phép thử RNG; xác định cơ chế phụ thuộc luồng.
- [ ] Xác định và xử lý chênh lệch XGBoost với kết quả primary lịch sử.
- [ ] UHS rà soát manuscript, claim traceability, bảng/hình và diễn giải MI/companion.
- [ ] Xác nhận submission version, định dạng và tài liệu cuối cùng.

Gói này là bản Repair v2 để review, chưa phải bản submission cuối.
