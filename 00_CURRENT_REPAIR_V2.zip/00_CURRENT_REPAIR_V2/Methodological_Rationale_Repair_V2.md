# Methodological Rationale — Repair v2
Primary vẫn sử dụng RATCAT_A. NHIS 2024 cung cấp 10 imputations income xếp chồng theo IMPNUM_A; cần ghép đúng HHX, không coi 326.290 dòng income là các người độc lập.[1]

Sensitivity thay RATCAT_A bằng POVRATTC_A liên tục, giữ 12 constructs và HHX train/validation/test split. Các LR/RF/XGBoost dùng hyperparameters, lựa chọn Raw/Platt và threshold đã khóa. Preprocessing fit trên train; Platt được fit lại trên phần validation có vai trò calibration. Trọng số train được chuẩn hóa về trung bình 1; evaluation được báo cáo riêng có/không WTFA_A.[4]

Mean, SD, min, max qua 10 imputations là mô tả predictive sensitivity. SD/range này không phải CI theo Rubin và không phản ánh đầy đủ bất định sampling. Không chọn lại mô hình hoặc threshold bằng test. Phân tích SHAP qua 10 imputations chưa thực hiện. RATCAT reference được chạy trong cùng môi trường để hỗ trợ so sánh; historical_runtime_drift_audit.csv ghi các chênh lệch với kết quả cũ. LR/RF khớp trong sai số số học; XGBoost còn lệch dù đã dùng 3.0.4. Nguyên nhân chưa xác định; cần xử lý trước khi tích hợp vào các claims primary lịch sử.

Companion dùng prevalence và Taylor SE/design df có sẵn, chỉ gồm hai outcome overall. Effective N = min(N, p(1-p)/SE²); điều chỉnh bằng bình phương tỷ số t-quantiles của N−1 và design df. Clopper–Pearson trên effective counts được tính bằng Beta quantiles và đối chiếu công thức F tương đương.[2] Không dùng Kish N thay cho variance-based effective N.

Companion báo cáo size/width criteria, statistical-review flag và độ tin cậy của complement theo NCHS.[3] Đây là tính toán bổ sung của dự án, không phải bảng CDC công bố hoặc đối chiếu SUDAAN/Stata. Chưa bổ sung companion cho subgroup.

Literature Matrix được phục hồi bằng bản sao nguyên vẹn CSV hiện hành 19 nguồn tại commit c6bab1a; không bổ sung hoặc xác minh lại 19 nghiên cứu trong lần bàn giao này.

## Nguồn
1. [CDC/NCHS. 2024 NHIS Survey Description, p.133 (2025).](https://ftp.cdc.gov/pub/health_statistics/nchs/dataset_documentation/NHIS/2024/srvydesc-508.pdf)
2. [Ward BW. kg_nchs: A command for Korn–Graubard confidence intervals. Stata Journal 19(3):510–522 (2019), equations 1–9.](https://stacks.cdc.gov/view/cdc/83564/cdc_83564_DS1.pdf)
3. [Parker JD et al. NCHS Data Presentation Standards for Proportions (2017; table correction 2021), pp.2–4.](https://www.cdc.gov/nchs/data/series/sr_02/sr02_175.pdf)
4. [HealthInfo_UIT, commit c6bab1a: poverty MI protocol and locked Day 8–13 configurations.](https://github.com/phatnbt/HealthInfo_UIT/tree/c6bab1a293afee2bdedddd301237863c94e6d82d)
## Compiler audit
Kiểm tra bổ sung 36 fits trên wheel MSVC, MSVC CPU và GCC CPU từ cùng source 3.0.4. GCC cho predictions giống nhau tại 1/2/4 luồng nhưng vẫn lệch lịch sử tối đa 0.0210922217437. Phép thử RNG chỉ ra rejection sampling trên MSVC tiêu thụ thêm bước engine, làm SimpleSkip theo số dòng không còn tương ứng giữa các luồng. Cơ chế phụ thuộc luồng được xác định; nguyên nhân đầy đủ của sai lệch lịch sử vẫn mở. Xem reproducibility/XGBOOST_COMPILER_INVESTIGATION.md và 72 evaluation rows trong compiler comparison CSV. Các outputs MI đã kiểm chứng được giữ nguyên.
