# Cơ sở phương pháp — bản Repair v2 đã sửa

Primary giữ RATCAT_A. Sensitivity thay bằng POVRATTC_A liên tục trong 10 datasets imputation, giữ HHX split, hyperparameters, threshold và lựa chọn Raw/Platt đã khóa. Preprocessing chỉ fit trên train; mapping Platt được fit lại trên calibration-role validation của từng arm. Không chọn lại mô hình bằng test.

MI global construct SHAP dùng cùng 128 test records trong tất cả arms của mỗi outcome. LR dùng independent/interventional linear SHAP và 500 train records làm background; RF dùng exact TreeSHAP ở thang base probability; XGBoost dùng exact native TreeSHAP trên CSR DMatrix ở thang raw margin. Cộng contributions của các encoded columns trong mỗi construct trước khi tính trị tuyệt đối và weighted aggregation.

Mean, SD, range và rank qua 10 imputations là mô tả sensitivity, không phải Rubin-pooled CI. SHAP không phân rã xác suất sau Platt, không chứng minh causal effect, fairness, clinical utility hoặc khả năng dùng ở Việt Nam. Additivity tolerance 3e-5 phản ánh số học float32 của tree margin.

Korn–Graubard sử dụng full-cohort domain Taylor SE/design df; giữ các PSU ngoài domain với contribution bằng zero. Taylor được đối chiếu với implementation độc lập dùng array PSU totals; KG được đối chiếu Beta/F từng hàng. Effective N dựa trên variance, không dùng Kish N thay thế. Lọc domain N≥30 cho 74 subgroup; cộng 2 overall thành 76 hàng tổng. Size, width, review và complement flags được giữ. Không tuyên bố đã đối chiếu phần mềm chính thức NCHS.

Runtime Linux đã đạt historical metric reproduction cho cả ba models. Windows XGBoost vẫn khác; số package version giống nhau không bảo đảm native behavior giống nhau. Corrected primary SHAP được phiên bản hóa riêng, giữ sparse semantics, trên estimator đạt gate; các hình XGBoost cũ dùng dense được supersede thay vì trộn vào kết quả mới.

Day22 freeze gốc được giữ nguyên. Workbook18 được khôi phục bằng các entry có CRC gốc hợp lệ, không dựng lại từ CSV19. Planned candidate branches vẫn được theo dõi riêng; không tự nhận đã chạy hoặc đã được UHS duyệt loại bỏ.
