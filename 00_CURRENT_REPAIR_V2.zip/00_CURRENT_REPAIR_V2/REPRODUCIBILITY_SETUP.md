# Tái lập Repair v2
Python đã dùng: 3.12.10. Đã cài và kiểm chứng trên virtualenv mới, không dùng system/user-site-packages, chạy Python với -I. Môi trường thư viện độc lập trên cùng máy Windows; chưa kiểm chứng trên máy hoặc Linux build khác. requirements.txt khóa toàn bộ 11 dependencies đã cài, gồm SciPy 1.17.0 và XGBoost 3.0.4 của bản gốc. Pip check đạt PASS; phiên bản XGBoost trong Python và native library đều 3.0.4.

Giữ cấu trúc thư mục khi giải nén PACKAGE.zip ngay tại 00_CURRENT_REPAIR_V2. PACKAGE chỉ chứa 13 tệp code, cấu hình đã khóa và bằng chứng manuscript/bảng cần đối chiếu. Các kết quả mới ở poverty_mi/ và survey_prevalence/ bên ngoài PACKAGE.

Mở PowerShell tại 00_CURRENT_REPAIR_V2:
```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip check
Expand-Archive -LiteralPath NHIS2024_Repair_V2_PACKAGE.zip -DestinationPath .
```
Đảm bảo Python thực tế là 3.12.10 nếu cần đối chiếu chính xác. Đặt dữ liệu tải riêng từ CDC vào inputs/:
- adult24csv.zip: https://ftp.cdc.gov/pub/health_Statistics/nchs/Datasets/NHIS/2024/adult24csv.zip
- adultinc24csv.zip: https://ftp.cdc.gov/pub/health_Statistics/nchs/Datasets/NHIS/2024/adultinc24csv.zip

Không có microdata trong gói. Script kiểm tra MD5 CSV, số dòng, khóa HHX/IMPNUM_A, đủ 10 imputations và đúng cohort/split counts trước khi fit.
```powershell
.\.venv\Scripts\python.exe -I -u NHIS2024_Repair_V2_PACKAGE/run_repair_analysis.py --reference-dir NHIS2024_Repair_V2_PACKAGE/reference --out-dir rerun_outputs --adult-zip inputs/adult24csv.zip --income-zip inputs/adultinc24csv.zip --n-jobs 4
```
Để chỉ tái tính companion từ prevalence nguồn, thay đối số dữ liệu bằng --kg-only. Lần chạy đầy đủ có 132 fits: 120 sensitivity và 12 RATCAT reference; xuất 240 dòng sensitivity và 24 dòng reference. Script yêu cầu XGBoost 3.0.4 đã khóa trước khi chạy MI.

Hai tiến trình trong môi trường mới đã chạy đầy đủ; bảy CSV kết quả khớp trong tolerance 1e−8, sai khác lớn nhất 5.55111512313e-17. Xem reproducibility/INDEPENDENT_VERIFICATION.md và audit files. Giữ 4 luồng khi đối chiếu gói này; diagnostic 1/2/4 luồng xác nhận XGBoost thay đổi theo số luồng trên build Windows hiện tại. LR/RF khớp lịch sử; XGBoost chưa khớp lịch sử nên mục này còn mở.

Manifest có scope handoff hoặc package, đường dẫn tương đối trong từng scope. Không tự hash manifest, summary JSON, PACKAGE.zip hoặc PACKAGE.sha256 để tránh phụ thuộc vòng. PACKAGE.zip được kiểm tra bằng PACKAGE.sha256; SHA-256 của ZIP ngoài được cung cấp riêng. Historical 152-file manifest chưa được cung cấp; manifest này ghi đúng gói rút gọn thực tế.

## Nguồn
1. [CDC/NCHS. 2024 NHIS Survey Description, p.133 (2025).](https://ftp.cdc.gov/pub/health_statistics/nchs/dataset_documentation/NHIS/2024/srvydesc-508.pdf)
2. [Ward BW. kg_nchs: A command for Korn–Graubard confidence intervals. Stata Journal 19(3):510–522 (2019), equations 1–9.](https://stacks.cdc.gov/view/cdc/83564/cdc_83564_DS1.pdf)
3. [Parker JD et al. NCHS Data Presentation Standards for Proportions (2017; table correction 2021), pp.2–4.](https://www.cdc.gov/nchs/data/series/sr_02/sr02_175.pdf)
4. [HealthInfo_UIT, commit c6bab1a: poverty MI protocol and locked Day 8–13 configurations.](https://github.com/phatnbt/HealthInfo_UIT/tree/c6bab1a293afee2bdedddd301237863c94e6d82d)

## Native build và compiler
Kiểm tra bổ sung 36 fits trên wheel MSVC, MSVC CPU và GCC CPU từ cùng source 3.0.4. GCC cho predictions giống nhau tại 1/2/4 luồng nhưng vẫn lệch lịch sử tối đa 0.0210922217437. Phép thử RNG chỉ ra rejection sampling trên MSVC tiêu thụ thêm bước engine, làm SimpleSkip theo số dòng không còn tương ứng giữa các luồng. Cơ chế phụ thuộc luồng được xác định; nguyên nhân đầy đủ của sai lệch lịch sử vẫn mở. Xem reproducibility/XGBOOST_COMPILER_INVESTIGATION.md và 72 evaluation rows trong compiler comparison CSV. Các outputs MI đã kiểm chứng được giữ nguyên.
Native SHA-256 của wheel dùng cho outputs bàn giao: f3e0d736906e07da5387c63816b398a73a85261aa7217ce8593309e5aa53eb07. Chỉ đối chiếu outputs dưới native build và 4 luồng đã ghi; xgboost==3.0.4 trên compiler khác không bảo đảm cùng số.
