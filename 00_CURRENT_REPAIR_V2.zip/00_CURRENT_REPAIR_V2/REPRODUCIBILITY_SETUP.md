# Tái lập Repair v2 đã sửa

Dùng Python 3.12.10 và requirements.txt. Các phiên bản thư viện trực tiếp vẫn theo bản gốc; file này khóa thêm thư viện phụ thuộc, với NVIDIA NCCL riêng cho Linux. Package version không đủ đảm bảo tái lập XGBoost: cần ghi native-library SHA-256, compiler/build info và số luồng.

**Runtime Linux đã kiểm chứng** tái lập cả LR/RF/XGBoost trong tolerance 1e-8. Windows wheel vẫn khác XGBoost lịch sử; không dùng Windows để khẳng định đã khôi phục primary XGBoost.

Giải nén PACKAGE.zip tại thư mục này. Tải riêng hai ZIP NHIS 2024 từ CDC vào inputs/. Gói không chứa microdata. Script kiểm MD5, số dòng, HHX, đủ 10 imputations và cohort/split trước khi fit.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip check
Expand-Archive -LiteralPath NHIS2024_Repair_V2_PACKAGE.zip -DestinationPath .
.\.venv\Scripts\python.exe -I -u NHIS2024_Repair_V2_PACKAGE/run_repair_analysis.py --reference-dir NHIS2024_Repair_V2_PACKAGE/reference --out-dir rerun_outputs --adult-zip inputs/adult24csv.zip --income-zip inputs/adultinc24csv.zip --n-jobs 4 --include-shap --shap-sample-size 128
.\.venv\Scripts\python.exe -I NHIS2024_Repair_V2_PACKAGE/reference/scripts/finalize_day4_post_uhs.py inputs/adult24csv.zip inputs/adultinc24csv.zip
.\.venv\Scripts\python.exe -I NHIS2024_Repair_V2_PACKAGE/reference/scripts/run_survey_companion.py --data-dir nhis_day4_post_uhs_final --out-dir rerun_outputs/survey_prevalence
```

Trên Linux thay đường dẫn interpreter bằng `.venv/bin/python`. Lượt chạy đầu có 132 fits và tính 2 KG overall; lệnh survey tiếp theo bổ sung toàn bộ 76 hàng. Để chạy tất cả gate lịch sử và gate release, dùng clone GitHub đầy đủ theo CURRENT_REPAIR_STATUS.md; gói code rút gọn không chứa toàn bộ 30 artifact freeze.

MI performance và sampled global SHAP là sensitivity. SHAP dùng 128 test records cố định mỗi outcome, không phải toàn bộ test. Corrected primary SHAP dùng toàn bộ 6.417/6.419 test records trên runtime Linux đạt gate. Giữ hai loại kết quả trong thư mục riêng.

Nguồn: [CDC NHIS 2024](https://www.cdc.gov/nchs/nhis/documentation/2024-nhis.html), [NCHS proportion standards](https://www.cdc.gov/nchs/data/series/sr_02/sr02_175.pdf), [Ward 2019 KG implementation](https://stacks.cdc.gov/view/cdc/83564/cdc_83564_DS1.pdf).
