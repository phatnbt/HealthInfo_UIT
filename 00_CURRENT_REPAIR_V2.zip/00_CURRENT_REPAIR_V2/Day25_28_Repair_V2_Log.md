# Repair execution log — 2026-09-15

## Current verified status

Independent Ubuntu verification is complete. The 132-fit MI/reference workflow reproduced the historical LR, RF and XGBoost metrics within the required tolerance of 1e-8; maximum XGBoost difference was 1.11e-16. A separate strict six-fit workflow completed corrected native-CSR full-test SHAP on all 6,417/6,419 test records; maximum additivity residual was 7.15e-6. Canonical MI and corrected primary explanations now use the verified Linux release. Windows results remain dated diagnostic evidence of native-runtime portability differences. UHS/venue approval remains NOT_SUPPLIED.

## Initial Windows repair stage — dated record

UTC record created: 2026-09-14T18:24:31.591410+00:00. MI full run completed: 2026-09-14T18:21:08.966830+00:00. Parent source: 2bf0792340ccfa179a7da171deb5ebdee7301661; exact repaired source/raw/native hashes are in repair/repair_execution_provenance.json and the run/audit JSONs.

Executed 132 locked MI/reference fits and six current-runtime RATCAT explanation fits on Windows Python3.12.10, n_jobs4, seed2026. MI has240 performance rows,2880 sampled constructSHAP rows and120 additivity checks. Maximum additivity residual7.1526e-6. Survey reconstruction has74 subgroup plus2 overall,76 total; independently verified Taylor and Beta/F KG formulas.

Restored LF working bytes without changing Day22 freeze hashes; fixed portable Day5 CLI, implemented predictorSVG, legend copies, C16 locator and current status/citation boundaries. Recovered original workbook18 from17 CRC-valid local entries. Confirmed sparse-to-dense XGB explanation defect; old XGB SHAP quarantined and native CSR TreeSHAP supplied in a separate runtime-sensitivity lane.

At this initial Windows stage, LR/RF historical retraining passed and XGBoost failed tolerance. Ubuntu verification was still pending at that timestamp. This paragraph records the earlier stage and does not describe the current verified status above. Final UHS/venue approval was not supplied. Optional sensitivity branches and unavailable historical logs/manifest are explicit in repair/SCOPE_REGISTER.csv; the optional branches are not incomplete Day 3–4 requirements. This is a new execution log and does not replace historical Day25–28 journals.

## Subsequent Linux verification — completed

The two completed Linux workflows and their evidence are the basis of the current status at the top of this log. Manuscript V2 and source traceability were updated from corrected full-test tables; no model parameters, split, calibration choice or threshold changed.
