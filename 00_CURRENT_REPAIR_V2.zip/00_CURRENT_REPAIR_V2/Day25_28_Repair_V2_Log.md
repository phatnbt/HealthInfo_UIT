# Nhật ký Repair v2 — nhóm việc Day 25–28
Thời điểm hoàn tất UTC: 2026-09-14T17:29:25.416873+00:00. Đây là nhật ký mới của lần sửa và bàn giao hiện tại, không phải nhật ký nghiên cứu lịch sử Day 25–28 đã phục hồi.

## Day 25 — kiểm tra hiện trạng
Đối chiếu source commit c6bab1a và danh sách deliverables. Xác định chưa có kết quả predictive MI và companion; Literature Matrix CSV 19 nguồn đã tồn tại. Gói nguồn 156 tệp không được giữ toàn bộ trong bản rút gọn.

## Day 26 — bổ sung tính toán
Tải hai ZIP public-use NHIS 2024 từ CDC; kiểm tra MD5 CSV khớp source audit. Thực hiện 120 fits qua 10 imputations, hai outcomes, ba models, hai training-weight arms; thêm 12 RATCAT reference fits trong cùng môi trường. Không thay protocol bằng test-based reselection. Chỉ xuất aggregate.

## Day 27 — đối chiếu kết quả
Đủ 240 MI performance rows, 20 cohort/split audit rows và 24 reference rows. Mỗi arm có đủ 10 imputations. Tính companion cho hai overall outcomes và kiểm tra Beta/F formulations khớp. Tái tính prevalence, Taylor SE và design df từ raw adult CSV, khớp inputs companion trong sai số 1e−14. XGBoost được chạy lại bằng bản 3.0.4 đã khóa. Chênh lệch tuyệt đối lớn nhất trong các metrics reference so với lịch sử: 0.0181306513991; xem drift audit.

## Day 28 — bàn giao
Tạo report, Closure Register, rationale, setup, dependency pins và checklist; giới hạn PACKAGE ở 13 tệp hỗ trợ cần thiết. Kiểm tra hashes/CRC và cấu trúc ZIP. Đã cài virtualenv mới độc lập và chạy đầy đủ hai tiến trình, tổng 264 fits; thêm 12 fits diagnostic bằng cohort do script gốc tạo. Bảy CSV khớp giữa hai tiến trình trong sai số 5.55111512313e-17. Mục môi trường mới đã đóng; XGBoost so với lịch sử, UHS final review và submission còn mở. Nhật ký môi trường chi tiết nằm trong reproducibility/.

## Kiểm tra bổ sung
Kiểm tra bổ sung 36 fits trên wheel MSVC, MSVC CPU và GCC CPU từ cùng source 3.0.4. GCC cho predictions giống nhau tại 1/2/4 luồng nhưng vẫn lệch lịch sử tối đa 0.0210922217437. Phép thử RNG chỉ ra rejection sampling trên MSVC tiêu thụ thêm bước engine, làm SimpleSkip theo số dòng không còn tương ứng giữa các luồng. Cơ chế phụ thuộc luồng được xác định; nguyên nhân đầy đủ của sai lệch lịch sử vẫn mở. Xem reproducibility/XGBOOST_COMPILER_INVESTIGATION.md và 72 evaluation rows trong compiler comparison CSV. Các outputs MI đã kiểm chứng được giữ nguyên.
Hai bảng lịch sử Day 8–10/11–13 có sáu rows chung khớp trong tolerance 1e−8.
