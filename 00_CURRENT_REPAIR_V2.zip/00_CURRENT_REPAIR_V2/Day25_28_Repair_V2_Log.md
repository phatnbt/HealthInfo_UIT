# Repair execution log — 2026-09-15

UTC record created: 2026-09-14T18:24:31.591410+00:00. MI full run completed: 2026-09-14T18:21:08.966830+00:00. Parent source: 2bf0792340ccfa179a7da171deb5ebdee7301661; exact repaired source/raw/native hashes are in repair/repair_execution_provenance.json and the run/audit JSONs.

Executed 132 locked MI/reference fits and six current-runtime RATCAT explanation fits on Windows Python3.12.10, n_jobs4, seed2026. MI has240 performance rows,2880 sampled constructSHAP rows and120 additivity checks. Maximum additivity residual7.1526e-6. Survey reconstruction has74 subgroup plus2 overall,76 total; independently verified Taylor and Beta/F KG formulas.

Restored LF working bytes without changing Day22 freeze hashes; fixed portable Day5 CLI, implemented predictorSVG, legend copies, C16 locator and current status/citation boundaries. Recovered original workbook18 from17 CRC-valid local entries. Confirmed sparse-to-dense XGB explanation defect; old XGB SHAP quarantined and native CSR TreeSHAP supplied in a separate runtime-sensitivity lane.

LR/RF historical retraining pass; XGB still fails tolerance. Ubuntu GitHub Actions verification is being tracked separately; a configured workflow is not a completed result. Final UHS/venue approval not supplied. Deferred candidate branches and unavailable historical logs/manifest are explicit in repair/SCOPE_REGISTER.csv. This is a new execution log and does not replace historical Day25–28 journals.
