#include <random>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <vector>
#include <cstdint>
using Engine=std::linear_congruential_engine<std::uint64_t,16807,0,(std::uint64_t(1)<<63)>;
struct Counted {using result_type=Engine::result_type;Engine e;size_t calls=0;explicit Counted(uint64_t s):e(s){} static constexpr result_type min(){return Engine::min();}static constexpr result_type max(){return Engine::max();}result_type operator()(){++calls;return e();}};
uint64_t skip(uint64_t exponent,uint64_t seed){uint64_t result=1,base=16807,mod=(uint64_t(1)<<63);while(exponent){if(exponent%2)result=(result*base)%mod;base=(base*base)%mod;exponent>>=1;}return (result*seed)%mod;}
int main(){
std::mt19937 mt(2026);auto seed=mt();
std::bernoulli_distribution coin(.85);Counted counted(seed);for(int i=0;i<10000;i++)coin(counted);std::cout<<"bernoulli_engine_calls "<<counted.calls<<"\n";
std::vector<int> ref;for(int jobs:{1,2,4}){std::vector<int> sampled(10000);int part=10000/jobs;for(int t=0;t<jobs;t++){int begin=t*part,end=t==jobs-1?10000:begin+part;Engine e(skip(begin,seed));for(int i=begin;i<end;i++)sampled[i]=coin(e);}if(jobs==1)ref=sampled;int diff=0;for(int i=0;i<10000;i++)diff+=ref[i]!=sampled[i];std::cout<<"row_sample_difference_threads "<<jobs<<" "<<diff<<"\n";}
std::mt19937 column_rng(2026);std::vector<int> cols(30);std::iota(cols.begin(),cols.end(),0);std::shuffle(cols.begin(),cols.end(),column_rng);std::cout<<"shuffled_columns";for(int n:cols)std::cout<<" "<<n;std::cout<<"\n";
using WideMT=std::mersenne_twister_engine<uint64_t,32,624,397,31,0x9908b0df,11,0xffffffff,7,0x9d2c5680,15,0xefc60000,18,1812433253>;
WideMT wide_rng(2026);std::iota(cols.begin(),cols.end(),0);std::shuffle(cols.begin(),cols.end(),wide_rng);std::cout<<"shuffled_columns_wide_MT";for(int n:cols)std::cout<<" "<<n;std::cout<<"\n";
}
