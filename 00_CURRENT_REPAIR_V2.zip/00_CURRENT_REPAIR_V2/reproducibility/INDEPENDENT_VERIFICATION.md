# Kiểm chứng môi trường Python độc lập
Đã chạy lại phân tích trong một virtualenv Python 3.12.10 mới, không dùng system-site-packages, không dùng user-site và chạy Python với -I. Đây là môi trường thư viện độc lập trên cùng máy Windows, không phải máy hoặc hệ điều hành thứ hai. Pip check đạt PASS; cả bảy thư viện trực tiếp được import từ virtualenv, native XGBoost đúng 3.0.4.

## Kết quả
Hai tiến trình Python độc lập chạy đầy đủ cùng code phân tích đã giải nén từ gói bàn giao: mỗi tiến trình có 132 fits, 240 MI performance rows, 20 cohort/split audit rows và 24 RATCAT reference rows. Mỗi arm có đủ 10 imputations. Bảy CSV kết quả được so sánh cấu trúc, các trường chuỗi và mọi trường số; sai khác số lớn nhất là 5.55111512313e-17, trong tolerance 1e−8. Không có dữ liệu người tham gia được xuất vào gói.

Script gốc finalize_day4_post_uhs.py kiểm tra checksum nguồn và tạo cohort thành công. Prevalence, Taylor SE và design df tính lại từ cohort gốc khớp inputs companion trong sai số 1e−14. Companion gồm hai outcome overall, với công thức Beta và F tương đương khớp.

## Đối chiếu kết quả lịch sử
| Model | Rows | Sai khác metric tuyệt đối lớn nhất | Trạng thái ở tolerance 1e−8 |
|---|---:|---:|---|
| LR | 8 | 2.99760216649e-15 | PASS |
| RF | 8 | 9.71445146547e-17 | PASS |
| XGBoost | 8 | 0.0181306513991 | FAIL |

Baseline XGBoost từ cohort do script gốc tạo ra khớp baseline từ code bổ sung ở 4 luồng. Diagnostic 12 fits tại 1, 2 và 4 luồng cho thấy predictions thay đổi khi đổi số luồng; cả ba cấu hình vẫn không tái lập các rows XGBoost lịch sử trong tolerance. Giữ 4 luồng cho bản kiểm chứng hiện tại, theo cấu hình của lần chạy bàn giao; không chọn số luồng dựa trên test performance.

Nguyên nhân đầy đủ của discrepancy lịch sử chưa xác định. Các artifacts hiện có thiếu thông tin OS/compiler và thread settings của lần chạy gốc, cũng không có serialized locked estimators. Tài liệu XGBoost lưu ý reproducibility phụ thuộc môi trường và dữ liệu; điều này hỗ trợ kiểm tra runtime, nhưng không chứng minh riêng nguyên nhân của discrepancy trong dự án.[1]

## Phạm vi sử dụng
Các CSV hiện tại được thay bằng outputs của lần chạy fresh environment và đã kiểm chứng tính lặp lại. RATCAT reference và POVRATTC_A được tính trong cùng môi trường, giữ model parameters/split/probability choice/threshold đã khóa. Mục tái lập môi trường Python mới đã hoàn thành. Mục khớp XGBoost với bản lịch sử vẫn OPEN; chưa tích hợp các kết quả mới vào claims primary lịch sử hoặc đánh dấu submission cuối.

Tái lập thành công chứng minh tính lặp lại dưới điều kiện đã ghi, không chứng minh độ chính xác lâm sàng hoặc loại bỏ sampling/model uncertainty. Mean/SD/range qua imputations không phải Rubin-pooled CI. Gói cũ đã không còn ở workspace lúc đối chiếu, nên kiểm tra này so sánh hai tiến trình mới và artifacts lịch sử, không khẳng định đã so sánh từng tệp với gói cũ.

## Bằng chứng
- fresh_environment_audit.json: isolation, đường dẫn modules, versions, native XGBoost và build metadata.
- independent_output_comparison.csv: so sánh đầy đủ bảy CSV giữa hai tiến trình mới.
- historical_reproduction_by_model.csv: PASS/FAIL theo model với tolerance ghi rõ.
- xgboost_official_cohort_thread_audit.csv: diagnostic bằng cohort từ script gốc.
- official_cohort_and_Taylor_input_audit.csv: checks cohort/split và prevalence inputs.
- requirements.txt ở thư mục cha: đầy đủ dependency pins đã cài trong môi trường mới, gồm SciPy 1.17.0.

## Nguồn
1. XGBoost developers. [Distributed XGBoost with Dask — Reproducible Results, release 3.0](https://xgboost.readthedocs.io/en/release_3.0.0/tutorials/dask.html#reproducible-result). Tài liệu về reproducibility; không phải bằng chứng xác nhận root cause của classifier này.
2. HealthInfo_UIT, [commit c6bab1a](https://github.com/phatnbt/HealthInfo_UIT/tree/c6bab1a293afee2bdedddd301237863c94e6d82d), scripts/finalize_day4_post_uhs.py và scripts/day11_13_survey_sensitivity.py; cohort/split definitions, nguồn đối chiếu và tolerance 1e−8.

## Kiểm tra compiler bổ sung

Đã bổ sung 36 fits trên ba native runtimes và phép thử RNG tổng hợp, giữ nguyên mô hình đã khóa. GCC 14.2 cho predictions giống nhau tại 1/2/4 luồng, nhưng vẫn lệch lịch sử tối đa 0.0210922217437. MSVC CPU mới và wheel MSVC đều thay đổi theo số luồng. Phép thử chỉ ra rejection sampling của thư viện C++ có thể tiêu thụ thêm bước RNG, làm SimpleSkip theo số dòng mất tính tương ứng giữa các luồng. Cơ chế phụ thuộc luồng được xác định; nguyên nhân đầy đủ của discrepancy lịch sử vẫn OPEN.

Sáu rows chung giữa bảng Day 8–10 và Day 11–13 khớp trong tolerance 1e−8. Xem [báo cáo compiler](XGBOOST_COMPILER_INVESTIGATION.md) với nguồn sơ cấp, số liệu và giới hạn; xgboost_compiler_comparison.csv lưu đủ 72 evaluation rows. Outputs MI đã kiểm chứng trước đó được giữ nguyên, không thay bằng baseline của runtime khác.
