# Kiểm tra compiler và RNG của XGBoost

Bản GCC vẫn chưa tái lập đầy đủ lịch sử trong tolerance 1e−8. Khác biệt RNG/build đã được chứng minh bằng thực nghiệm, nhưng chưa giải thích toàn bộ discrepancy lịch sử. Các phép thử giữ nguyên seed 2026, hyperparameters, HHX split, preprocessing, lựa chọn Raw/Platt, calibration weights và threshold đã khóa. Không chọn mô hình theo test performance.

## Đối chiếu mô hình đã khóa

Mỗi runtime có 12 fits: hai outcomes × hai training-weight arms × ba số luồng; mỗi fit được đánh giá có/không WTFA_A, tạo 24 rows. Tổng 36 fits và 72 evaluation rows. Cùng cohort do script gốc tạo và cùng dependencies trong virtualenv độc lập được dùng cho cả ba runtime. msvc là wheel PyPI 3.0.4 đã kiểm chứng trước đó; msvc_cpu và gcc được build từ cùng tag v3.0.4, commit 0915f5fdb16e669947eaa6bcf6826fa585b55962, CPU-only/OpenMP/Release.[1]

Sai khác là giá trị tuyệt đối lớn nhất trên tám rows mỗi số luồng và bảy metrics AUROC, AUPRC, Brier, Recall, Precision, F1, Specificity, đối chiếu với bảng Day 11–13 đã lưu ở commit c6bab1a của dự án.[2]

| Runtime | Luồng | Sai khác metric tuyệt đối lớn nhất | Tolerance 1e−8 |
|---|---:|---:|---|
| msvc | 1 | 0.0121789096915 | FAIL |
| msvc | 2 | 0.0157880820458 | FAIL |
| msvc | 4 | 0.0181306513991 | FAIL |
| msvc_cpu | 1 | 0.0140009496989 | FAIL |
| msvc_cpu | 2 | 0.0160983981821 | FAIL |
| msvc_cpu | 4 | 0.0159720260496 | FAIL |
| gcc | 1 | 0.0210922217437 | FAIL |
| gcc | 2 | 0.0210922217437 | FAIL |
| gcc | 4 | 0.0210922217437 | FAIL |

GCC có predictions giống nhau tại 1/2/4 luồng: True. MSVC wheel và bản MSVC CPU đều có predictions thay đổi theo số luồng. Metadata và SHA-256 native library nằm trong xgboost_compiler_investigation.json; các số gốc, số lịch sử, differences và prediction hashes nằm trong xgboost_compiler_comparison.csv. Không có predictions hoặc microdata cá nhân trong gói.

Đối chiếu sáu rows chung giữa bảng Day 8–10 và arm unweighted/unweighted của Day 11–13: sai khác lớn nhất trên mười trường metric/probability là 3.83005870075e-09, đạt tolerance 1e−8. Hai bảng lịch sử nhất quán về số liệu; kiểm tra này không xác nhận metadata build của lần chạy ban đầu. Bản MSVC CPU mới cũng khác wheel Windows (max metric difference 0,0159817351598; không có prediction hash nào giống trong 24 rows), nên không coi hai build MSVC là cùng binary.

## Cơ chế lấy mẫu theo dòng

XGBoost 3.0.4 chia các dòng thành từng đoạn theo số luồng, dùng SimpleSkip để bỏ qua số bước bằng vị trí dòng bắt đầu và gọi std::bernoulli_distribution cho mỗi dòng. Cách chia này cho chuỗi giống nhau khi mỗi dòng tiêu thụ đúng một bước của engine.[3] Trong Microsoft STL mới, generate_canonical dùng rejection sampling khi range của engine không là lũy thừa của hai; một kết quả có thể tiêu thụ thêm bước engine.[4]

Phép thử tổng hợp random_runtime_probe.cpp dùng đúng loại linear_congruential_engine, tham số base/modulus và SimpleSkip của bộ lấy mẫu, seed MT19937 2026, 10.000 dòng và xác suất 0,85. GCC tiêu thụ 10.000 lần gọi engine; MSVC tiêu thụ 10.013. Khi tăng từ một lên hai/bốn luồng, GCC đổi 0/0 lựa chọn dòng; MSVC đổi 1.263/1.954 lựa chọn dòng. Đây là số từ phép thử tổng hợp, không phải số bệnh nhân hoặc số dòng thay đổi trong từng cây NHIS.

Với engine có min=1, max=2^63−1 và double 53 bits, thuật toán MSVC được kiểm tra có giới hạn chấp nhận floor((2^63−1)/2^53)×2^53; phần dư khiến khoảng 1/1024 lần lấy mẫu cần thêm bước. SimpleSkip vẫn đếm số dòng, nên các ranh giới luồng không còn tương ứng với chuỗi một luồng. Đây là cơ chế thực nghiệm giải thích tính phụ thuộc luồng của bộ lấy mẫu đang kiểm tra; không cần thay đổi random_state.

Microsoft hợp nhất đặc tả generate_canonical mới vào tháng 6/2024 và ghi thay đổi trong release VS 2022 17.12. Vì vậy chỉ ghi Python package version 3.0.4 chưa khóa được hành vi thư viện C++.[5] Phép thử cũng cho std::shuffle tạo thứ tự cột khác nhau giữa GCC và MSVC với cùng seed; XGBoost gọi hàm này khi colsample không có feature_weights.[6] Các khác biệt row sampling, column sampling và build có thể đồng thời tác động; kiểm tra hiện tại không tách tỷ lệ đóng góp của từng cơ chế vào mỗi metric.

## Diễn giải và bàn giao

Tái lập khác với hiệu năng lâm sàng: PASS ở tolerance chỉ xác nhận số được khôi phục dưới điều kiện đã ghi. Không tăng seed, thay subsample/colsample hay chọn threshold để làm các số giống lịch sử. Native build/compiler phải được ghi cùng package version, OS và thread settings trong tài liệu tái lập.

Chưa có metadata OS/compiler của lần chạy lịch sử hoặc serialized locked estimators. Bản GCC được chạy trên Windows/MinGW, nên không khẳng định đã kiểm chứng trên máy Linux riêng hay xác nhận OS ban đầu. Các kết quả MI đang bàn giao vẫn là outputs Windows đã lặp lại trong hai tiến trình; không tự thay bằng outputs của phép thử compiler baseline. Nếu dùng runtime khác cho MI, cần chạy lại toàn bộ 10 imputations và kiểm chứng outputs tương ứng trước khi tích hợp manuscript.

## Nguồn

1. XGBoost contributors. [Source tag v3.0.4](https://github.com/dmlc/xgboost/tree/0915f5fdb16e669947eaa6bcf6826fa585b55962), CMakeLists.txt và src/; build CPU-only cùng mã nguồn. GCC toolchain: [Winlibs GCC 14.2.0, MinGW-w64 12.0.0 UCRT, release 3](https://github.com/brechtsanders/winlibs_mingw/releases/tag/14.2.0posix-12.0.0-ucrt-r3), archive SHA-256 được đối chiếu asset checksum.
2. HealthInfo_UIT. [Commit c6bab1a](https://github.com/phatnbt/HealthInfo_UIT/tree/c6bab1a293afee2bdedddd301237863c94e6d82d), scripts/day8_10_modeling.py, scripts/day11_13_survey_sensitivity.py và modeling/day11_13/day11_13_weighted_model_sensitivity.csv.
3. XGBoost contributors. [hist/sampler.h, v3.0.4](https://raw.githubusercontent.com/dmlc/xgboost/v3.0.4/src/tree/hist/sampler.h), RandomReplace::SimpleSkip và SampleGradient.
4. Microsoft. [STL random header, VS 2022 17.14](https://raw.githubusercontent.com/microsoft/STL/vs-2022-17.14/stl/inc/random), generate_canonical và bernoulli_distribution. GCC. [libstdc++ random.tcc, GCC 14.2.0](https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-14.2.0/libstdc++-v3/include/bits/random.tcc), generate_canonical. C++ probe được biên dịch tại chỗ với MSVC 19.51 và GCC 14.2.
5. Microsoft. [P0952R2 implementation, PR 4740](https://github.com/microsoft/STL/pull/4740), merged June 27, 2024; [STL release notes, VS 2022 17.12](https://github.com/microsoft/STL/releases/tag/vs-2022-17.12).
6. XGBoost contributors. [common/random.cc, v3.0.4](https://raw.githubusercontent.com/dmlc/xgboost/v3.0.4/src/common/random.cc), ColumnSampler::ColSample, std::shuffle.
